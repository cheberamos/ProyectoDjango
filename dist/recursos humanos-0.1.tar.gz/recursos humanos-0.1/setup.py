from setuptools import setup

setup (
    name="recursos humanos",
    version="0.1",
    description="Paquete de ejemplo de empleados y nomina",
    author="Cramos",
    author_email="cheberamos@gmail.com",
    url="https://codoacodo.com",
    package= ['recursos_humanos','recursos_humanos.personal'],
    script=[]
)